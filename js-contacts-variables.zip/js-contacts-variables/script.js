let contactOneName = "Alice Johnson";
let contactOnePhone = "902-555-1234";
let contactOneEmail = "alice@example.com";

let contactTwoName = "Mark Smith";
let contactTwoPhone = "902-555-5678";
let contactTwoEmail = "mark@example.com";

let contactThreeName = "Sara Brown";
let contactThreePhone = "902-555-9012";
let contactThreeEmail = "sara@example.com";

document.getElementById("firstName1").textContent = contactOneName;
document.getElementById("firstPhone1").textContent = contactOnePhone;
document.getElementById("firstEmail1").textContent = contactOneEmail;

document.getElementById("lastName3").textContent = contactThreeName;
document.getElementById("lastPhone3").textContent = contactThreePhone;
document.getElementById("lastEmail3").textContent = contactThreeEmail;